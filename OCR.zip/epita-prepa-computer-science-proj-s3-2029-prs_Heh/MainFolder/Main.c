
#include "Main_Header.h"


static void on_button_clicked(GtkWidget* button, gpointer user_data) {
    struct Widgets* widgets = user_data;

    GtkTextBuffer* buffer = gtk_text_view_get_buffer(widgets->text_view);
    GtkTextIter start, end;
    gtk_text_buffer_get_bounds(buffer, &start, &end);
    char* text = gtk_text_buffer_get_text(buffer, &start, &end, FALSE);

    if (g_file_test("Image.bmp", G_FILE_TEST_EXISTS)) {
        if (remove("Image.bmp") != 0) {
            g_print("Impossible de supprimer l'ancien Image.bmp\n");
        }
    }

    g_print("Texte entrer : %s\n", text);
    int i = run_sdl_image(text);

    if (i == 1) {
        g_free(text);
    }
    else {
        gtk_image_set_from_file(GTK_IMAGE(widgets->image_widget), "Image.bmp");
        if (widgets->original_pixbuf) {
            g_object_unref(widgets->original_pixbuf);
            widgets->original_pixbuf = NULL;
        }
        widgets->current_angle = 0.0;
        g_free(text);
    }
}

static void rotate_right(GtkWidget* button, gpointer user_data) {
    struct Widgets* widgets = (struct Widgets*)user_data;
    if (!widgets || !widgets->image_widget) return;

    if (!widgets->original_pixbuf) {
        GError* error = NULL;
        widgets->original_pixbuf = gdk_pixbuf_new_from_file("Image.bmp", &error);
        if (!widgets->original_pixbuf) {
            g_print("Erreur lors du chargement de l'image : %s\n", error->message);
            g_error_free(error);
            return;
        }
        widgets->current_angle = 0.0;
    }

    widgets->current_angle += 10.0;
    double angle_rad = widgets->current_angle * G_PI / 180.0;

    int width = gdk_pixbuf_get_width(widgets->original_pixbuf);
    int height = gdk_pixbuf_get_height(widgets->original_pixbuf);
    int size = (int)ceil(sqrt(width * width + height * height));

    cairo_surface_t* surface = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, size, size);
    cairo_t* cr = cairo_create(surface);
    cairo_set_operator(cr, CAIRO_OPERATOR_SOURCE);
    cairo_set_source_rgba(cr, 0, 0, 0, 0);
    cairo_paint(cr);
    cairo_translate(cr, size / 2.0, size / 2.0);
    cairo_rotate(cr, angle_rad);
    cairo_translate(cr, -width / 2.0, -height / 2.0);

    gdk_cairo_set_source_pixbuf(cr, widgets->original_pixbuf, 0, 0);
    cairo_paint(cr);

    GdkPixbuf* rotated = gdk_pixbuf_get_from_surface(surface, 0, 0, size, size);
    gtk_image_set_from_pixbuf(GTK_IMAGE(widgets->image_widget), rotated);
    cairo_destroy(cr);
    cairo_surface_destroy(surface);

    g_print("Rotation cumul?e : %.1f? (surface %dx%d)\n", widgets->current_angle, size, size);
}

static void rotate_left(GtkWidget* button, gpointer user_data) {
    struct Widgets* widgets = (struct Widgets*)user_data;
    if (!widgets || !widgets->image_widget) return;

    if (!widgets->original_pixbuf) {
        GError* error = NULL;
        widgets->original_pixbuf = gdk_pixbuf_new_from_file("Image.bmp", &error);
        if (!widgets->original_pixbuf) {
            g_print("Erreur lors du chargement de l'image : %s\n", error->message);
            g_error_free(error);
            return;
        }
        widgets->current_angle = 0.0;
    }

    widgets->current_angle -= 10.0;
    double angle_rad = widgets->current_angle * G_PI / 180.0;

    int width = gdk_pixbuf_get_width(widgets->original_pixbuf);
    int height = gdk_pixbuf_get_height(widgets->original_pixbuf);
    int size = (int)ceil(sqrt(width * width + height * height));

    cairo_surface_t* surface = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, size, size);
    cairo_t* cr = cairo_create(surface);
    cairo_set_operator(cr, CAIRO_OPERATOR_SOURCE);
    cairo_set_source_rgba(cr, 0, 0, 0, 0);
    cairo_paint(cr);
    cairo_translate(cr, size / 2.0, size / 2.0);
    cairo_rotate(cr, angle_rad);
    cairo_translate(cr, -width / 2.0, -height / 2.0);

    gdk_cairo_set_source_pixbuf(cr, widgets->original_pixbuf, 0, 0);
    cairo_paint(cr);

    GdkPixbuf* rotated = gdk_pixbuf_get_from_surface(surface, 0, 0, size, size);
    gtk_image_set_from_pixbuf(GTK_IMAGE(widgets->image_widget), rotated);
    cairo_destroy(cr);
    cairo_surface_destroy(surface);

    g_print("Rotation cumul?e : %.1f? (surface %dx%d)\n", widgets->current_angle, size, size);
}

static void treatement(GtkWidget* button, gpointer user_data) {
    struct Widgets* widgets = (struct Widgets*)user_data;
    const char* filename = "Image.bmp";

    if (!g_file_test(filename, G_FILE_TEST_EXISTS)) {
        g_print("Image non trouv?e. Veuillez d'abord cliquer sur 'Executer'.\n");
        return;
    }

    if (SDL_Init(SDL_INIT_VIDEO) != 0) {
        g_print("Erreur SDL_Init: %s\n", SDL_GetError());
        return;
    }

    SDL_Surface* surface = SDL_LoadBMP(filename);
    if (!surface) {
        g_print("Impossible de charger %s: %s\n", filename, SDL_GetError());
        SDL_Quit();
        return;
    }

    image_split_x(surface);
    SDL_FreeSurface(surface);
    char* outputDir = "letters";
    char* outputDir1 = "splitletters";

    extractLettersToFolder("grid.bmp", outputDir, "Grid.txt");
    extractLettersToFolder("list.bmp", outputDir1,"Word.txt");
    
    g_print("Traitement termin? : images s?par?es et lettres extraites.\n");
    int nb_lignes = 0;

    char** liste = ReadFileLines(&nb_lignes);
    printf("between read file lines and exec solver\n");
    int i = ExecuteSolver(nb_lignes, liste);
    if (i != 0) {
        errx(EXIT_FAILURE, "Solver Failed");
    }
    printf("end of treatement");
}

static void activate(GtkApplication* app, gpointer user_data) {
    GtkWidget* window = gtk_application_window_new(app);
    gtk_window_set_title(GTK_WINDOW(window), "Solver OCR");
    gtk_window_set_default_size(GTK_WINDOW(window), 1280, 720);

    GtkWidget* main_box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 10);
    gtk_container_add(GTK_CONTAINER(window), main_box);

    // Image widget
/*    GtkWidget* image_widget = gtk_image_new();
    gtk_widget_set_size_request(image_widget, 800, 600);
    gtk_box_pack_start(GTK_BOX(main_box), image_widget, TRUE, TRUE, 0);
*/

    GtkWidget* image_box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
    gtk_box_pack_start(GTK_BOX(main_box), image_box, TRUE, TRUE, 0);
    GtkWidget* image_widget = gtk_image_new();
    gtk_widget_set_size_request(image_widget, 800, 600);
    gtk_box_pack_start(GTK_BOX(image_box), image_widget, TRUE, TRUE, 0);
    // Input box
    GtkWidget* input_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 10);
    gtk_box_pack_start(GTK_BOX(main_box), input_box, FALSE, FALSE, 0);

    GtkWidget* text_view = gtk_text_view_new();
    gtk_text_view_set_wrap_mode(GTK_TEXT_VIEW(text_view), GTK_WRAP_NONE);
    gtk_widget_set_size_request(text_view, 400, 50);
    gtk_box_pack_start(GTK_BOX(input_box), text_view, TRUE, TRUE, 0);

    GtkWidget* green_button = gtk_button_new_with_label("Executer");
    gtk_widget_set_size_request(green_button, 150, 50);
    gtk_box_pack_start(GTK_BOX(input_box), green_button, FALSE, FALSE, 0);

    // Rotation buttons
    GtkWidget* rotate_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 10);
    gtk_box_pack_start(GTK_BOX(main_box), rotate_box, FALSE, FALSE, 0);

    GtkWidget* left_button = gtk_button_new_with_label("Rotate Left");
    GtkWidget* Middle_button = gtk_button_new_with_label("Apply treatment");
    GtkWidget* right_button = gtk_button_new_with_label("Rotate Right");

    gtk_box_pack_start(GTK_BOX(rotate_box), left_button, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(rotate_box), Middle_button, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(rotate_box), right_button, TRUE, TRUE, 0);

    // Structure for callbacks
    struct Widgets* widgets = g_new0(struct Widgets, 1);
    widgets->text_view = GTK_TEXT_VIEW(text_view);
    widgets->image_widget = GTK_IMAGE(image_widget);

    // Connect callbacks
    g_signal_connect(green_button, "clicked", G_CALLBACK(on_button_clicked), widgets);
    g_signal_connect(left_button, "clicked", G_CALLBACK(rotate_left), widgets);
    g_signal_connect(Middle_button, "clicked", G_CALLBACK(treatement), widgets);
    g_signal_connect(right_button, "clicked", G_CALLBACK(rotate_right), widgets);

    gtk_widget_show_all(window);
}

int main(int argc, char** argv) {

        GtkApplication* app = gtk_application_new("com.GtkTreatment", G_APPLICATION_DEFAULT_FLAGS);
        g_signal_connect(app, "activate", G_CALLBACK(activate), NULL);
        int status = g_application_run(G_APPLICATION(app), argc, argv);
        g_object_unref(app);
        return status;
}
