#ifndef MAIN_HEADER_H
#define MAIN_HEADER_H

#include <SDL2/SDL.h>
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include <gtk/gtk.h>
#include <dirent.h>
#include <math.h>
#include <cairo.h>
#include <time.h>
#include <err.h>
#include <ctype.h>
#include <glib.h>

struct Widgets {
     GtkTextView* text_view;
     GtkImage* image_widget;
     GdkPixbuf* original_pixbuf;
     double current_angle;
};
typedef struct {
    int nb_entrees;
    int nb_cacher;   // taille de chaque couche cach?e (ici on assume m?me taille pour H1,H2,H3)
    int nb_sorties;
    double learning_rate;

    // vecteurs d'activation
    double* entree;
    double* cacher1;
    double* cacher2;
    double* cacher3;
    double* sortie;

    // biais
    double* b_hidden1;
    double* b_hidden2;
    double* b_hidden3;
    double* b_output;

    // poids (tableaux de pointeurs)
    double** w_input_hidden1;     // [nb_entrees][nb_cacher]
    double** w_hidden1_hidden2;   // [nb_cacher][nb_cacher]
    double** w_hidden2_hidden3;   // [nb_cacher][nb_cacher]
    double** w_hidden3_output;    // [nb_cacher][nb_sorties]
} NeuralNetwork;
//SDL functions
double*image_to_array(char*path);
int run_sdl_image(const char* text);
void image_split_x(SDL_Surface* surface);
void extractLettersToFolder(const char* inputFile, const char* outputDir, const char* filewrite);

//NeuralNetwork Functions



NeuralNetwork* create_network(int n_input, int n_hidden, int n_output, double lr);
NeuralNetwork* load_network(const char* filename);
int ValuesToFile(NeuralNetwork* nn, double* inputs);
void Saver(NeuralNetwork* nn, const char* filename);
int Trainer(NeuralNetwork* nn, int epochs);
void Free_All(NeuralNetwork* nn);
//Solver Functions

int ExecuteSolver(int argc, char* argv[]);
char** ReadFileLines(int* nb_lignes);



#endif
