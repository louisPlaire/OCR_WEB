


#include "Main_Header.h"

#if defined(_WIN32)
#include <direct.h> // pour _mkdir
#define MKDIR(dir) _mkdir(dir)
#else
#include <sys/stat.h>
#include <sys/types.h>
#define MKDIR(dir) mkdir(dir, 0777)
#endif

void Clean_Ressources(SDL_Surface* picture) {
    if (picture) SDL_FreeSurface(picture);
}



// Main Function : Convert and save picture
int run_sdl_image(const char* filepath) {
    SDL_Surface* picture = SDL_LoadBMP(filepath);
    if (!picture) {
        SDL_Log("Erreur chargement image: %s\n", SDL_GetError());
        return 1;
    }

    if (SDL_MUSTLOCK(picture)) SDL_LockSurface(picture);

    int w = picture->w;
    int h = picture->h;
    const Uint8 threshold = 200;
    for (int i = 0; i < h; i++) {
        Uint8* row = (Uint8*)picture->pixels + i * picture->pitch;
        Uint32* pixels = (Uint32*)row;
        for (int j = 0; j < w; j++) {
            Uint32 pixel = pixels[j];
            Uint8 r, g, b;
            SDL_GetRGB(pixel, picture->format, &r, &g, &b);
            Uint8 gray = 0.299 * r + 0.587 * g + 0.114 * b;
            Uint8 bin = (gray > threshold) ? 255 : 0;
            pixels[j] = SDL_MapRGB(picture->format, bin, bin, bin);
        }
    }

    if (SDL_MUSTLOCK(picture)) SDL_UnlockSurface(picture);

    // Save Image in black and white
    if (SDL_SaveBMP(picture, "Image.bmp") != 0) {
        SDL_Log("Erreur sauvegarde image: %s\n", SDL_GetError());
        Clean_Ressources(picture);
        return 1;
    }

    Clean_Ressources(picture);
    return 0;
}

// Function to rotate image 
int rotate_image_90(const char* filepath, int clockwise) {
    SDL_Surface* picture = SDL_LoadBMP(filepath);
    if (!picture) {
        fprintf(stderr, "Erreur chargement image : %s\n", SDL_GetError());
        return 1;
    }

    int w = picture->w;
    int h = picture->h;

    SDL_Surface* rotated = SDL_CreateRGBSurfaceWithFormat(0, h, w, 32, picture->format->format);
    if (!rotated) {
        fprintf(stderr, "Erreur cr ation surface : %s\n", SDL_GetError());
        SDL_FreeSurface(picture);
        return 1;
    }

    Uint32* src = (Uint32*)picture->pixels;
    Uint32* dst = (Uint32*)rotated->pixels;

    for (int y = 0; y < h; y++) {
        for (int x = 0; x < w; x++) {
            Uint32 pixel = src[y * w + x];

            if (clockwise) {
                // Rotation vers la droite
                dst[x * rotated->w + (rotated->w - y - 1)] = pixel;
            }
            else {
                // Rotation vers la gauche
                dst[(rotated->h - x - 1) * rotated->w + y] = pixel;
            }
        }
    }

    if (SDL_SaveBMP(rotated, filepath) != 0) {
        fprintf(stderr, "Erreur sauvegarde : %s\n", SDL_GetError());
    }

    SDL_FreeSurface(rotated);
    SDL_FreeSurface(picture);
    return 0;
}

Uint32 rgb_to_pixel(Uint8 r, Uint8 g, Uint8 b)
{
    return 255 * pow(2, 24) + r * pow(2, 16) + g * pow(2, 8) + b;
}

Uint8 to_gray(Uint8 r, Uint8 g, Uint8 b)
{
    Uint8 gray = 0.299 * r + 0.587 * g + 0.114 * b;
    return gray;
}

int is_white(Uint32 pixel)
{
    return pixel == 4294967295;
}


static inline Uint8* pixel_ref(SDL_Surface* surf, unsigned x, unsigned y)
{
    int bpp = surf->format->BytesPerPixel;
    return (Uint8*)surf->pixels + y * surf->pitch + x * bpp;
}


// get pixel in bmp thanks to its coordinates x = width and y = height
Uint32 get_pixel(SDL_Surface* img, unsigned x, unsigned y)
{
    Uint8* p = pixel_ref(img, x, y);

    switch (img->format->BytesPerPixel)
    {
    case 1:
        return *p;

    case 2:
        return *(Uint16*)p;

    case 3:
        if (SDL_BYTEORDER == SDL_BIG_ENDIAN)
            return p[0] << 16 | p[1] << 8 | p[2];
        else
            return p[0] | p[1] << 8 | p[2] << 16;

    case 4:
        return *(Uint32*)p;
    }

    return 0;
}


void set_pixel(SDL_Surface* img, unsigned x, unsigned y, Uint32 pixel)
{
    Uint8* p = pixel_ref(img, x, y);

    switch (img->format->BytesPerPixel)
    {
    case 1:
        *p = pixel;
        break;

    case 2:
        *(Uint16*)p = pixel;
        break;

    case 3:
        if (SDL_BYTEORDER == SDL_BIG_ENDIAN)
        {
            p[0] = (pixel >> 16) & 0xff;
            p[1] = (pixel >> 8) & 0xff;
            p[2] = pixel & 0xff;
        }
        else
        {
            p[0] = pixel & 0xff;
            p[1] = (pixel >> 8) & 0xff;
            p[2] = (pixel >> 16) & 0xff;
        }
        break;

    case 4:
        *(Uint32*)p = pixel;
        break;
    }
}


void image_split_x(SDL_Surface* surface)
{
    int w = surface->w;
    int h = surface->h;
    static int count = 0;

    SDL_Surface* left = SDL_CreateRGBSurfaceWithFormat(0, w, h, 32, surface->format->format);
    SDL_Surface* right = SDL_CreateRGBSurfaceWithFormat(0, w, h, 32, surface->format->format);

    int first_black_encountered = 0;
    int white_encountered_again = 0;
    int is_column_white = 0;

    int x = 0;
    int splitX = 0;
    while (white_encountered_again == 0) {
        for (int y = 0; y < h; y++) {
            Uint32 pixel = get_pixel(surface, x, y);
            if (!is_white(pixel)) first_black_encountered = 1;
            set_pixel(left, x, y, pixel);
        }
        if (first_black_encountered) {
            is_column_white += 1;
            for (int y = 0; y < h; y++) {
                if (!is_white(get_pixel(surface, x, y))) is_column_white = 0;
            }
            if (is_column_white == 10) {
                white_encountered_again = 1;
                splitX = x - 9; 
            }
        }
        x++;
    }

    int is_left_list = 0;
    if (splitX < w / 2) {
        if (SDL_SaveBMP(left, "list.bmp") != 0)
            fprintf(stderr, "Erreur sauvegarde : %s\n", SDL_GetError());
        is_left_list = 1;
    }
    else {
        if (SDL_SaveBMP(left, "grid.bmp") != 0)
            fprintf(stderr, "Erreur sauvegarde : %s\n", SDL_GetError());
    }

    while (x < w) {
        for (int y = 0; y < h; y++) {
            Uint32 pixel = get_pixel(surface, x, y);
            set_pixel(right, x - splitX, y, pixel); 
        }
        x++;
    }

    if (is_left_list) {
        if (SDL_SaveBMP(right, "grid.bmp") != 0)
            fprintf(stderr, "Erreur sauvegarde : %s\n", SDL_GetError());
    }
    else {
        if (SDL_SaveBMP(right, "list.bmp") != 0)
            fprintf(stderr, "Erreur sauvegarde : %s\n", SDL_GetError());
    }
}


typedef struct {
    int x, y;
} Point;

typedef struct {
    int minX, maxX, minY, maxY;
} BoundingBox;

void floodFillIterative(Uint32* pixels, Uint8* visited, int w, int h,int startX, int startY, SDL_PixelFormat* fmt, Uint8 threshold, BoundingBox* box) {
    const int maxSize = w * h;
    Point* queue = malloc(sizeof(Point) * maxSize);
    int qStart = 0, qEnd = 0;

    queue[qEnd++] = (Point){ startX, startY };
    visited[startY * w + startX] = 1;

    while (qStart < qEnd) {
        Point p = queue[qStart++];
        int x = p.x, y = p.y;

        if (x < box->minX) box->minX = x;
        if (x > box->maxX) box->maxX = x;
        if (y < box->minY) box->minY = y;
        if (y > box->maxY) box->maxY = y;

        // 4-connected neighbors
        const int dx[4] = { 1, -1, 0, 0 };
        const int dy[4] = { 0, 0, 1, -1 };

        for (int i = 0; i < 4; i++) {
            int nx = x + dx[i];
            int ny = y + dy[i];
            if (nx < 0 || nx >= w || ny < 0 || ny >= h) continue;

            int nidx = ny * w + nx;
            if (visited[nidx]) continue;

            Uint8 r, g, b;
            SDL_GetRGB(pixels[nidx], fmt, &r, &g, &b);
            Uint8 brightness = (r + g + b) / 3;

            if (brightness > threshold) continue; // background

            visited[nidx] = 1;
            queue[qEnd++] = (Point){ nx, ny };
        }
    }

    free(queue);
}

double* image_to_array(char* path)
{
    SDL_Surface* image = SDL_LoadBMP(path);
    if (!image) {
        printf("Unable to load image %s: %s\n", path, SDL_GetError());

        return NULL;
    }

    size_t width = 32;
    size_t height = 32;
    double* res = malloc(width * height * sizeof(double));
    if (!res) {
        printf("Memory allocation failed in image_to_array\n");
        SDL_FreeSurface(image);
        return NULL;
    }

    for (size_t y = 0; y < height; y++)
    {
        for (size_t x = 0; x < width; x++)
        {
            Uint32 pixel = get_pixel(image, x, y);
            if (is_white(pixel) == 1)
                res[y * width + x] = 0.0;
            else
                res[y * width + x] = 1.0;
        }
    }

    SDL_FreeSurface(image); 
    return res;
}

void extractLettersToFolder(const char* inputFile, const char* outputDir, const char* filewrite) {
    if (SDL_Init(SDL_INIT_VIDEO) != 0) {
        printf("SDL_Init Error: %s\n", SDL_GetError());
        return;
    }

    SDL_Surface* image = SDL_LoadBMP(inputFile);
    if (!image) {
        printf("Unable to load image %s: %s\n", inputFile, SDL_GetError());
        SDL_Quit();
        return;
    }

    if (SDL_LockSurface(image) != 0) {
        printf("Unable to lock surface: %s\n", SDL_GetError());
        SDL_FreeSurface(image);
        SDL_Quit();
        return;
    }

    int w = image->w, h = image->h;
    Uint32* pixels = (Uint32*)image->pixels;

    Uint8* visited = calloc(w * h, 1);
    if (!visited) {
        printf("Memory allocation failed.\n");
        SDL_UnlockSurface(image);
        SDL_FreeSurface(image);
        SDL_Quit();
        return;
    }

    FILE* fichier = fopen(filewrite, "w");
    if (!fichier) {
        printf("Cannot open file %s\n", filewrite);
        free(visited);
        SDL_UnlockSurface(image);
        SDL_FreeSurface(image);
        SDL_Quit();
        return;
    }

    NeuralNetwork* NN = create_network(1024, 25, 26, 0.1);
    if (!NN) {
        printf("Failed to load neural network.\n");
        fclose(fichier);
        free(visited);
        SDL_UnlockSurface(image);
        SDL_FreeSurface(image);
        SDL_Quit();
        return;
    }

    NN = load_network("SaverReseau.bin");

    BoundingBox reference;

    const Uint8 threshold = 200;
    int letterCount = 0;

    int letters_on_this_line = 0;
    int lines = 0;
    int det = lines;
    for (int y = 0; y < h; y++) {
        if(y % reference.maxY == 0)
        {
            lines++;
        }
        letters_on_this_line = 0;
        for (int x = 0; x < w; x++) {

            int idx = y * w + x;
            if (visited[idx]) continue;
            //printf("visited");
            Uint8 r, g, b;
            SDL_GetRGB(pixels[idx], image->format, &r, &g, &b);

            Uint8 brightness = (r + g + b) / 3;
            if (brightness > threshold) continue;
            //printf("brightness");
            BoundingBox box = { x, x, y, y };
            floodFillIterative(pixels, visited, w, h, x, y, image->format, threshold, &box);
            reference = box;


            int bw = box.maxX - box.minX + 1;
            int bh = box.maxY - box.minY + 1;
            if (bw < 3 || bh < 3) continue;
            //printf("bw bh");
            SDL_Surface* letter = SDL_CreateRGBSurface(0, bw, bh, 32,
                0x00FF0000, 0x0000FF00, 0x000000FF, 0xFF000000);

            if (!letter) continue;
            //printf("letter");
            Uint32* dst = (Uint32*)letter->pixels;
            for (int ly = 0; ly < bh; ly++) {
                for (int lx = 0; lx < bw; lx++) {
                    dst[ly * bw + lx] = pixels[(box.minY + ly) * w + (box.minX + lx)];
                }
            }

            char filename[512];
            snprintf(filename, sizeof(filename), "%s/letter_%03d.bmp", outputDir, letterCount);

            SDL_Surface* to_save = SDL_CreateRGBSurfaceWithFormat(0, 32, 32, 32, letter->format->format);
            if (!to_save) {
                SDL_FreeSurface(letter);
                continue;
            }
            //printf("to_save");
            SDL_BlitScaled(letter, NULL, to_save, NULL);

            // filters white images
            int black_pixels = 0;
            int white_pixels = 0;

            for(int y = 0; y < 32; y++)
            {
                for(int x = 0; x < 32; x++)
                {
                    Uint32 p = get_pixel(to_save, x, y);
                    if(p != 0)
                    {
                        black_pixels++;
                    }
		    if(is_white(p))
			    white_pixels++;
                }
            }

            if (black_pixels > 0 && white_pixels > 64)
            {
                if (SDL_SaveBMP(to_save, filename) == 0)
                {



                    double* input = image_to_array(filename);

                    if (!input) {
                        SDL_FreeSurface(to_save);
                        SDL_FreeSurface(letter);
                        continue;
                    }

                    int val = ValuesToFile(NN, input);
                    //printf("input");

                    char letters = (char)(val + 'A');
                    printf("%c", letters);
                    fputc(letters, fichier);
                    letters_on_this_line++;
                    SDL_FreeSurface(to_save);
                    letterCount++;
                    free(input);
                }
            }
            SDL_FreeSurface(letter);
        }
        if (letters_on_this_line > 0 && det != lines) {
            det = lines;
            fputc('\n', fichier);
        }
    }

    if (fclose(fichier) != 0) {
        fprintf(stderr, "Erreur durant la fermeture du fichier\n");

        Free_All(NN);
        free(visited);
        SDL_UnlockSurface(image);
        SDL_FreeSurface(image);
        SDL_Quit();
        return;
    }

    printf("\nExtracted %d letters.\n", letterCount);
    Free_All(NN);
    free(visited);
    SDL_UnlockSurface(image);
    SDL_FreeSurface(image);

    SDL_Quit();
}


void test()
{
	double* a = image_to_array("../splitletters/letter_015.bmp");

	for(size_t y = 0; y < 32; y++)
	{
		for(size_t x = 0; x < 32; x++)
		{
			printf("%f ", a[y*32 +x]);
		}
		printf("\n");
	}

	free(a);
}
